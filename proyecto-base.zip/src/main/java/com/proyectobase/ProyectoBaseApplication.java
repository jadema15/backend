package com.proyectobase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoBaseApplication.class, args);
	}

}
