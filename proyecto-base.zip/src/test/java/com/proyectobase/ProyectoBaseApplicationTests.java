package com.proyectobase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
